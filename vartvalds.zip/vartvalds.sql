-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 13, 2020 at 02:45 PM
-- Server version: 5.7.29-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vartvalds`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_guests`
--

CREATE TABLE `active_guests` (
  `ip` varchar(15) NOT NULL,
  `timestamp` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `active_guests`
--

INSERT INTO `active_guests` (`ip`, `timestamp`) VALUES
('127.0.0.1', 1605271339);

-- --------------------------------------------------------

--
-- Table structure for table `active_users`
--

CREATE TABLE `active_users` (
  `username` varchar(30) NOT NULL,
  `timestamp` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `banned_users`
--

CREATE TABLE `banned_users` (
  `username` varchar(30) NOT NULL,
  `timestamp` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`) VALUES
(9, 'Vilnius'),
(10, 'Kaunas'),
(11, 'KlaipÄ—da'),
(12, 'Å iauliai'),
(13, 'Ryga');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `client_username` varchar(30) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `client_surname` varchar(100) NOT NULL,
  `trip_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `client_username`, `client_name`, `client_surname`, `trip_id`) VALUES
(16, 'Administratorius', 'Admin', 'Admin', 18),
(17, 'Administratorius', 'Admin', 'Admin1', 21),
(18, 'tomas', 'Tomas', 'Tom', 21),
(19, 'vadybininkas', 'vadybininkas ', 'va', 18),
(20, 'Administratorius', 'Tomas', 'StaÅ¡keviÄius', 18),
(21, 'tomas', '', '', 23),
(22, 'tomas', 'andrius', 'b', 23);

-- --------------------------------------------------------

--
-- Table structure for table `trains`
--

CREATE TABLE `trains` (
  `nr` int(11) NOT NULL,
  `seats_count` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trains`
--

INSERT INTO `trains` (`nr`, `seats_count`) VALUES
(100, 20),
(303, 14),
(404, 50),
(3003, 200);

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `id` int(11) NOT NULL,
  `departure_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ticket_count` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `train_nr` int(11) NOT NULL,
  `departure_city_id` int(11) NOT NULL,
  `arrival_city_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trips`
--

INSERT INTO `trips` (`id`, `departure_time`, `ticket_count`, `price`, `train_nr`, `departure_city_id`, `arrival_city_id`) VALUES
(18, '2020-11-06 05:19:00', 50, '6', 100, 9, 10),
(19, '2020-11-07 07:51:00', 99, '15', 303, 9, 11),
(20, '2020-11-06 13:27:00', 50, '6', 404, 10, 12),
(21, '2020-11-07 04:27:00', 2, '15', 303, 11, 10),
(22, '2020-11-02 11:08:00', 50, '5', 303, 12, 11),
(23, '2020-11-01 11:37:00', 55, '2', 100, 10, 12),
(24, '2020-11-06 12:30:00', 80, '3', 100, 9, 11);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(30) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `userid` varchar(32) DEFAULT NULL,
  `userlevel` tinyint(1) UNSIGNED NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `timestamp` int(11) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `userid`, `userlevel`, `email`, `timestamp`) VALUES
('Valdytojas', 'fe01ce2a7fbac8fafaed7c982a04e229', 'f508febebdc922ea0dd364e32749a629', 5, 'demo@ktu.lt', 1604541574),
('Administratorius', 'fe01ce2a7fbac8fafaed7c982a04e229', '9b381a2f2eddd37296e4726bd6104807', 9, 'demo@ktu.lt', 1604665776),
('Vartotojas', 'fe01ce2a7fbac8fafaed7c982a04e229', '9a47f4552955b91bcd8850d73b00e703', 1, 'demo@ktu.lt', 1330553730),
('tomas', 'eabd8ce9404507aa8c22714d3f5eada9', '984aeed624ef59fdc8590ab492c700fa', 1, 'aaa@gmail.com', 1604665514),
('tomas1', 'eabd8ce9404507aa8c22714d3f5eada9', '587edb570d8fc83793a5723c8a335157', 1, 'aaa1@gmail.com', 1604540549),
('vadybininkas', 'eabd8ce9404507aa8c22714d3f5eada9', 'd7e903dbbb67e63912114f4e50b9319a', 5, 'aaa0@gmail.com', 1604665606);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `active_guests`
--
ALTER TABLE `active_guests`
  ADD PRIMARY KEY (`ip`);

--
-- Indexes for table `active_users`
--
ALTER TABLE `active_users`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `banned_users`
--
ALTER TABLE `banned_users`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_trip_id` (`trip_id`);

--
-- Indexes for table `trains`
--
ALTER TABLE `trains`
  ADD PRIMARY KEY (`nr`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_train_nr` (`train_nr`),
  ADD KEY `fk_departure_city_id` (`departure_city_id`),
  ADD KEY `fk_arrival_city_id` (`arrival_city_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`),
  ADD KEY `username` (`username`),
  ADD KEY `username_2` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `trains`
--
ALTER TABLE `trains`
  MODIFY `nr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3004;
--
-- AUTO_INCREMENT for table `trips`
--
ALTER TABLE `trips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `fk_trip_id` FOREIGN KEY (`trip_id`) REFERENCES `trips` (`id`);

--
-- Constraints for table `trips`
--
ALTER TABLE `trips`
  ADD CONSTRAINT `fk_arrival_city_id` FOREIGN KEY (`arrival_city_id`) REFERENCES `cities` (`id`),
  ADD CONSTRAINT `fk_departure_city_id` FOREIGN KEY (`departure_city_id`) REFERENCES `cities` (`id`),
  ADD CONSTRAINT `fk_train_nr` FOREIGN KEY (`train_nr`) REFERENCES `trains` (`nr`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
