<?php
include("include/session.php");
if ($session->logged_in) {
		$servername = "localhost";
		$username = "stud";
		$password = "stud";
		$database = "vartvalds";
		$lentele="tickets";


		$conn = new mysqli($servername, $username, $password, $database);
		
		if($conn->connect_error) die("Nepavyko prisijungti: " . $conn->connect_error);
		
		
		
		if($_POST != null){
			$username = $_POST['username'];
			$ticket_id= $_POST['ticket_id'];
			$client_name = $_POST['client_name'];
			$client_surname = $_POST['client_surname'];
			$sql = "INSERT INTO $lentele(client_username,client_name,client_surname,trip_id) VALUES('$username','$client_name','$client_surname','$ticket_id')";
			if(!$result=$conn->query($sql)) die("Negaliu irasyti ".$conn->error);
			echo "Irasyta";
			$conn->close();
			header("Location:tickets.php?message=Bilietas užsakytas sėkmingai");exit;
		}
		
	
} else {
    header("Location: index.php");
}
?>