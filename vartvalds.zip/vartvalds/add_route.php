<?php
include("include/session.php");
if ($session->logged_in && $session->isAdmin()) {
		$servername = "localhost";
		$username = "stud";
		$password = "stud";
		$database = "vartvalds";
		$lentele="trips";


		$conn = new mysqli($servername, $username, $password, $database);
		
		if($conn->connect_error) die("Nepavyko prisijungti: " . $conn->connect_error);
		
		
		
		if($_POST != null){
			$departureTime = $_POST['departureTime'];
			$ticket_count = $_POST['ticket_count'];
			$price = $_POST['price'];
			$train = $_POST['train'];
			$departure_city = $_POST['departure_city'];
			$arrival_city = $_POST['arrival_city'];
			$sql = "INSERT INTO $lentele(departure_time,ticket_count,price,train_nr,departure_city_id,arrival_city_id) VALUES('$departureTime','$ticket_count','$price','$train','$departure_city','$arrival_city')";
			if(!$result=$conn->query($sql)) die("Negaliu irasyti ".$conn->error);
			echo "Irasyta";
			$conn->close();
			header("Location:administrate_trains.php?message=Reisas pridėtas sėkmingai");
			exit;
		}
		
	
} else {
    header("Location: index.php");
}
?>